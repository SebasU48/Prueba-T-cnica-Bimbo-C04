# Notas de entrega

Código de candidato:

Versión de Python usada:

## Qué funciona

- Nivel A:
- Nivel B:
- Nivel C:

## Cómo ejecutar y verificar

Comandos utilizados y resultados observados (incluye cantidad de pruebas aprobadas/fallidas):

## Decisiones

Explica dos decisiones: representación del dinero y orden de validación/deduplicación.

## Pruebas propias

Indica al menos dos escenarios, qué fallo detectan y dónde están las pruebas.

## Uso de IA

Herramienta(s), tareas asistidas, una sugerencia revisada y cómo la comprobaste. O indica que no la usaste.

## Pendientes y limitaciones

Qué falta, cómo lo abordarías y qué verificaste realmente. No declares pruebas ejecutadas si solo leíste el código.
