"""Conciliación de datos ficticios."""
