
"""Motor de conciliación de facturas y pagos.C04"""

import csv 
import re
from datetime import date
from pathlib import Path
from decimal import Decimal

FACTURAS = ("factura_id", "cliente_id", "fecha_vencimiento", "importe")
PAGOS = ("pago_id", "factura_id", "cliente_id", "fecha_pago", "importe")

RESUMEN = (
    "factura_id", "cliente_id", "fecha_vencimiento",
    "importe", "pagado", "saldo", "estado", "vencida"
)
INCIDENCIAS = ("archivo", "fila", "codigo", "referencia")

PATRON_FECHA = re.compile(r"^\d{4}-\d{2}-\d{2}$")
PATRON_DINERO = re.compile(r"^[0-9]+(?:[.,][0-9]{1,2})?$")
CERO = Decimal("0.00")


def normalizar(valor):
    return (valor or "").strip().upper()


def dinero(valor):
    texto = (valor or "").strip()

    if not re.fullmatch(r"[0-9]+(?:[.,][0-9]{1,2})?", texto):
        raise ValueError("Importe inválido")

    importe = Decimal(texto.replace(",", "."))

    if importe <= 0:
        raise ValueError("El importe debe ser mayor que cero")

    return importe.quantize(Decimal("0.01"))


def fecha(valor):
    texto = (valor or "").strip()
    if not PATRON_FECHA.fullmatch(texto):
        raise ValueError("Fecha inválida")
    return date.fromisoformat(texto)


def leer_csv(ruta, columnas):
    with Path(ruta).open(encoding="utf-8-sig", newline="") as archivo:
        lector = csv.DictReader(archivo)
        cabecera = lector.fieldnames

        if (
            cabecera is None
            or len(cabecera) != len(set(cabecera))
            or not set(columnas).issubset(cabecera)
        ):
            raise ValueError("Cabecera inválida: " + Path(ruta).name)

        for fila in lector:
            if not any(valor is not None and valor.strip()
                       for valor in fila.values() if isinstance(valor, str)):
                continue
            yield lector.line_num, fila


def fila_valida(fila, columnas):
    if None in fila:
        return False
    return all(fila.get(columna) is not None for columna in columnas)


def registrar(incidencias, archivo, numero, codigo, referencia=""):
    incidencias.append({
        "archivo": archivo,
        "fila": str(numero),
        "codigo": codigo,
        "referencia": referencia
    })


def conciliar(facturas_path, pagos_path, fecha_corte):
    corte = fecha(fecha_corte)
    facturas = {}
    pagos_ids = set()
    incidencias = []

    # Leer y validar facturas.
    for numero, fila in leer_csv(facturas_path, FACTURAS):
        factura_id = normalizar(fila.get("factura_id"))
        try:
            if not fila_valida(fila, FACTURAS):
                raise ValueError("Fila incompleta")

            cliente = normalizar(fila["cliente_id"])
            vencimiento = fecha(fila["fecha_vencimiento"])
            importe = dinero(fila["importe"])

            if not factura_id or not cliente:
                raise ValueError("Identificador vacío")

        except (ValueError, TypeError, AttributeError):
            registrar(incidencias, "facturas", numero,
                      "FILA_INVALIDA", factura_id)
            continue

        if factura_id in facturas:
            registrar(incidencias, "facturas", numero,
                      "FACTURA_DUPLICADA", factura_id)
            continue

        facturas[factura_id] = {
            "cliente": cliente,
            "vencimiento": vencimiento,
            "importe": importe,
            "pagado": CERO
        }

    # Leer y validar pagos.
    for numero, fila in leer_csv(pagos_path, PAGOS):
        pago_id = normalizar(fila.get("pago_id"))
        factura_id = normalizar(fila.get("factura_id"))

        try:
            if not fila_valida(fila, PAGOS):
                raise ValueError("Fila incompleta")

            cliente = normalizar(fila["cliente_id"])
            fecha_pago = fecha(fila["fecha_pago"])
            importe = dinero(fila["importe"])

            if not pago_id or not factura_id or not cliente:
                raise ValueError("Identificador vacío")

        except (ValueError, TypeError, AttributeError):
            registrar(incidencias, "pagos", numero,
                      "FILA_INVALIDA", pago_id or factura_id)
            continue

        if pago_id in pagos_ids:
            registrar(incidencias, "pagos", numero,
                      "PAGO_DUPLICADO", pago_id)
            continue

        pagos_ids.add(pago_id)

        if fecha_pago > corte:
            registrar(incidencias, "pagos", numero,
                      "PAGO_FUERA_CORTE", pago_id)
            continue

        if factura_id not in facturas:
            registrar(incidencias, "pagos", numero,
                      "FACTURA_NO_EXISTE", pago_id)
            continue

        factura = facturas[factura_id]
        if cliente != factura["cliente"]:
            registrar(incidencias, "pagos", numero,
                      "CLIENTE_NO_COINCIDE", pago_id)
            continue

        factura["pagado"] += importe

    # Construir resumen y totales.
    resumen = []
    total_importe = CERO
    total_pagado = CERO

    for factura_id, factura in sorted(facturas.items()):
        importe = factura["importe"]
        pagado = factura["pagado"]
        saldo = importe - pagado

        if pagado == 0:
            estado = "PENDIENTE"
        elif saldo > 0:
            estado = "PARCIAL"
        elif saldo == 0:
            estado = "PAGADA"
        else:
            estado = "SOBREPAGADA"

        vencida = "SI" if saldo > 0 and factura["vencimiento"] < corte else "NO"

        resumen.append({
            "factura_id": factura_id,
            "cliente_id": factura["cliente"],
            "fecha_vencimiento": factura["vencimiento"].isoformat(),
            "importe": f"{importe:.2f}",
            "pagado": f"{pagado:.2f}",
            "saldo": f"{saldo:.2f}",
            "estado": estado,
            "vencida": vencida
        })

        total_importe += importe
        total_pagado += pagado

    return {
        "resumen": resumen,
        "incidencias": incidencias,
        "totales": {
            "facturas_validas": len(resumen),
            "importe": f"{total_importe:.2f}",
            "pagado": f"{total_pagado:.2f}",
            "saldo": f"{total_importe - total_pagado:.2f}",
            "incidencias": len(incidencias)
        }
    }
