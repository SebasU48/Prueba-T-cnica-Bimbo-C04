import json
from pathlib import Path
import unittest
from conciliador.engine import conciliar, normalizar, dinero

ROOT = Path(__file__).resolve().parents[1]


class PruebasPublicas(unittest.TestCase):
    def setUp(self):
        self.datos = ROOT / "datos/ejemplo"

    def resultado(self):
        return conciliar(self.datos / "facturas.csv", self.datos / "pagos.csv", "2026-10-15")

    def test_01_identificadores(self):
        self.assertEqual(normalizar(" f100 "), "F100")

    def test_02_importe_coma(self):
        self.assertEqual(str(dinero("12,50")), "12.50")

    def test_03_acumula_pagos(self):
        self.assertEqual(self.resultado()["resumen"][0]["pagado"], "60.00")

    def test_04_sobrepago(self):
        self.assertEqual(self.resultado()["resumen"][3]["estado"], "SOBREPAGADA")

    def test_05_no_vence_el_mismo_dia(self):
        self.assertEqual(self.resultado()["resumen"][4]["vencida"], "NO")

    def test_06_incidencias(self):
        self.assertEqual(len(self.resultado()["incidencias"]), 7)

    def test_07_ejemplo_completo(self):
        esperado = json.loads((self.datos / "esperado.json").read_text(encoding="utf-8"))
        self.assertEqual(self.resultado(), esperado)


if __name__ == "__main__":
    unittest.main()
